-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 28, 2018 at 10:05 PM
-- Server version: 5.7.23-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lr_interview`
--

-- --------------------------------------------------------

--
-- Table structure for table `developers`
--

CREATE TABLE `developers` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `developers`
--

INSERT INTO `developers` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'shaley@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(2, 'berneice22@example.com', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(3, 'emil85@example.net', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(4, 'lew11@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(5, 'arvel.mante@example.com', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(6, 'aliza.abbott@example.net', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(7, 'ebert.zoila@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(8, 'ezra73@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(9, 'zgreenfelder@example.com', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(10, 'durward70@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(11, 'brooke.casper@example.net', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(12, 'vrau@example.com', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(13, 'carroll96@example.net', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(14, 'hrenner@example.org', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(15, 'jermain.hermann@example.net', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(16, 'hyatt.elliott@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(17, 'ubaldo36@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(18, 'damon12@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(19, 'ysanford@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(20, 'tillman.martin@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(21, 'armstrong.fidel@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(22, 'cmetz@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(23, 'percy39@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(24, 'auer.ivy@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(25, 'davis.florencio@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(26, 'leannon.graham@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(27, 'annie.schuppe@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(28, 'raynor.jana@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(29, 'fanderson@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(30, 'reina65@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(31, 'lilla59@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(32, 'gillian02@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(33, 'zoe99@example.net', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(34, 'fbeier@example.org', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(35, 'sabbott@example.com', '2018-09-28 15:19:26', '2018-09-28 15:19:26'),
(36, 'aric.keeling@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(37, 'zbarton@example.net', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(38, 'robel.jacquelyn@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(39, 'cleora24@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(40, 'jones.eldora@example.net', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(41, 'chris.towne@example.com', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(42, 'roslyn29@example.net', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(43, 'maritza87@example.com', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(44, 'hauer@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(45, 'dschmeler@example.com', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(46, 'mylene95@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(47, 'marcus33@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(48, 'beatrice66@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(49, 'jamey.mertz@example.com', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(50, 'donnelly.zena@example.org', '2018-09-28 15:19:27', '2018-09-28 15:19:27'),
(51, 'amaya19@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(52, 'brando13@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(53, 'carroll.daphnee@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(54, 'gabriel.yundt@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(55, 'dbechtelar@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(56, 'qdamore@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(57, 'nicklaus.feeney@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(58, 'hauck.nikolas@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(59, 'armando33@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(60, 'bskiles@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(61, 'mireya28@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(62, 'malcolm44@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(63, 'pacocha.kelvin@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(64, 'clarissa48@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(65, 'gilda.hessel@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(66, 'cruickshank.mayra@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(67, 'nnienow@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(68, 'telly.cummings@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(69, 'gweimann@example.org', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(70, 'oceane.bauch@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(71, 'farrell.tyson@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(72, 'hegmann.desmond@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(73, 'rprice@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(74, 'fritz47@example.com', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(75, 'garret79@example.net', '2018-09-28 15:19:28', '2018-09-28 15:19:28'),
(76, 'turner.johnathon@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(77, 'abashirian@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(78, 'ethan63@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(79, 'peggie.pouros@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(80, 'reynold.hayes@example.org', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(81, 'moen.glenda@example.com', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(82, 'rwunsch@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(83, 'joelle60@example.com', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(84, 'hal57@example.org', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(85, 'christiansen.maxwell@example.com', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(86, 'madelynn25@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(87, 'eldridge.mertz@example.com', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(88, 'ronny.quitzon@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(89, 'snitzsche@example.net', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(90, 'walter.lillie@example.com', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(91, 'claudine68@example.org', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(92, 'rabbott@example.org', '2018-09-28 15:19:29', '2018-09-28 15:19:29'),
(93, 'jordi.mueller@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(94, 'ksipes@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(95, 'gleason.lucy@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(96, 'kovacek.ariane@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(97, 'jabernathy@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(98, 'labadie.general@example.com', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(99, 'leon.senger@example.org', '2018-09-28 15:19:30', '2018-09-28 15:19:30'),
(100, 'kathlyn.hodkiewicz@example.net', '2018-09-28 15:19:30', '2018-09-28 15:19:30');

-- --------------------------------------------------------

--
-- Table structure for table `developer_language`
--

CREATE TABLE `developer_language` (
  `id` int(10) UNSIGNED NOT NULL,
  `developer_id` int(10) UNSIGNED NOT NULL,
  `language_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `developer_language`
--

INSERT INTO `developer_language` (`id`, `developer_id`, `language_id`) VALUES
(1, 1, 4),
(2, 1, 6),
(3, 2, 8),
(4, 3, 8),
(5, 4, 8),
(6, 5, 10),
(7, 6, 5),
(8, 6, 6),
(9, 7, 6),
(10, 7, 9),
(11, 7, 10),
(12, 8, 4),
(13, 8, 10),
(14, 9, 2),
(15, 9, 7),
(16, 9, 8),
(17, 10, 3),
(18, 10, 7),
(19, 11, 1),
(20, 11, 6),
(21, 11, 10),
(22, 12, 1),
(23, 12, 2),
(24, 13, 4),
(25, 13, 6),
(26, 13, 7),
(27, 14, 5),
(28, 14, 7),
(29, 15, 4),
(30, 15, 5),
(31, 16, 2),
(32, 16, 5),
(33, 16, 7),
(34, 17, 2),
(35, 17, 3),
(36, 17, 4),
(37, 18, 6),
(38, 18, 9),
(39, 19, 2),
(40, 19, 3),
(41, 20, 4),
(42, 20, 9),
(43, 20, 10),
(44, 21, 2),
(45, 22, 1),
(46, 22, 3),
(47, 23, 9),
(48, 24, 5),
(49, 24, 9),
(50, 24, 10),
(51, 25, 5),
(52, 25, 8),
(53, 25, 9),
(54, 26, 4),
(55, 26, 6),
(56, 26, 9),
(57, 27, 7),
(58, 28, 3),
(59, 28, 7),
(60, 29, 2),
(61, 29, 7),
(62, 29, 10),
(63, 30, 4),
(64, 30, 6),
(65, 30, 10),
(66, 31, 8),
(67, 32, 1),
(68, 32, 2),
(69, 32, 5),
(70, 33, 1),
(71, 34, 2),
(72, 34, 3),
(73, 35, 1),
(74, 35, 9),
(75, 36, 4),
(76, 36, 8),
(77, 37, 2),
(78, 37, 3),
(79, 37, 8),
(80, 38, 1),
(81, 38, 2),
(82, 39, 9),
(83, 40, 4),
(84, 40, 8),
(85, 41, 2),
(86, 41, 7),
(87, 42, 2),
(88, 42, 3),
(89, 42, 8),
(90, 43, 3),
(91, 43, 9),
(92, 43, 10),
(93, 44, 4),
(94, 44, 7),
(95, 45, 3),
(96, 45, 4),
(97, 45, 8),
(98, 46, 4),
(99, 46, 5),
(100, 47, 4),
(101, 47, 10),
(102, 48, 8),
(103, 49, 1),
(104, 49, 3),
(105, 49, 7),
(106, 50, 2),
(107, 50, 7),
(108, 51, 7),
(109, 52, 6),
(110, 52, 9),
(111, 53, 2),
(112, 53, 4),
(113, 53, 9),
(114, 54, 1),
(115, 54, 4),
(116, 55, 2),
(117, 55, 3),
(118, 55, 5),
(119, 56, 5),
(120, 57, 2),
(121, 57, 8),
(122, 57, 9),
(123, 58, 6),
(124, 58, 8),
(125, 58, 10),
(126, 59, 6),
(127, 59, 7),
(128, 60, 2),
(129, 60, 4),
(130, 60, 7),
(131, 61, 2),
(132, 61, 8),
(133, 61, 9),
(134, 62, 10),
(135, 63, 6),
(136, 63, 10),
(137, 64, 6),
(138, 65, 6),
(139, 65, 8),
(140, 66, 2),
(141, 66, 4),
(142, 67, 3),
(143, 67, 7),
(144, 67, 10),
(145, 68, 1),
(146, 68, 7),
(147, 69, 2),
(148, 70, 6),
(149, 71, 4),
(150, 71, 5),
(151, 71, 6),
(152, 72, 2),
(153, 72, 8),
(154, 73, 1),
(155, 73, 9),
(156, 74, 4),
(157, 74, 5),
(158, 75, 4),
(159, 75, 8),
(160, 75, 10),
(161, 76, 1),
(162, 76, 7),
(163, 76, 9),
(164, 77, 2),
(165, 77, 3),
(166, 77, 8),
(167, 78, 5),
(168, 78, 6),
(169, 78, 8),
(170, 79, 2),
(171, 79, 3),
(172, 80, 3),
(173, 80, 5),
(174, 80, 6),
(175, 81, 9),
(176, 82, 6),
(177, 82, 9),
(178, 82, 10),
(179, 83, 8),
(180, 84, 2),
(181, 84, 8),
(182, 85, 3),
(183, 85, 6),
(184, 85, 7),
(185, 86, 1),
(186, 86, 8),
(187, 87, 4),
(188, 88, 6),
(189, 89, 2),
(190, 89, 4),
(191, 89, 5),
(192, 90, 3),
(193, 90, 4),
(194, 91, 10),
(195, 92, 4),
(196, 92, 7),
(197, 93, 1),
(198, 94, 3),
(199, 94, 4),
(200, 95, 3),
(201, 96, 1),
(202, 96, 5),
(203, 96, 10),
(204, 97, 4),
(205, 97, 9),
(206, 98, 10),
(207, 99, 9),
(208, 100, 1),
(209, 100, 4),
(210, 100, 5);

-- --------------------------------------------------------

--
-- Table structure for table `developer_programming_language`
--

CREATE TABLE `developer_programming_language` (
  `id` int(10) UNSIGNED NOT NULL,
  `developer_id` int(10) UNSIGNED NOT NULL,
  `programming_language_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `developer_programming_language`
--

INSERT INTO `developer_programming_language` (`id`, `developer_id`, `programming_language_id`) VALUES
(1, 1, 10),
(2, 2, 1),
(3, 2, 9),
(4, 3, 1),
(5, 3, 4),
(6, 4, 8),
(7, 4, 9),
(8, 5, 10),
(9, 6, 1),
(10, 6, 5),
(11, 7, 2),
(12, 7, 4),
(13, 7, 7),
(14, 8, 1),
(15, 8, 7),
(16, 8, 8),
(17, 9, 3),
(18, 9, 6),
(19, 10, 1),
(20, 10, 7),
(21, 11, 6),
(22, 12, 1),
(23, 12, 5),
(24, 12, 7),
(25, 13, 2),
(26, 14, 10),
(27, 15, 3),
(28, 16, 2),
(29, 16, 3),
(30, 16, 4),
(31, 17, 2),
(32, 17, 4),
(33, 18, 1),
(34, 18, 7),
(35, 18, 8),
(36, 19, 4),
(37, 19, 6),
(38, 19, 10),
(39, 20, 1),
(40, 20, 2),
(41, 20, 7),
(42, 21, 2),
(43, 21, 3),
(44, 21, 4),
(45, 22, 3),
(46, 22, 5),
(47, 22, 7),
(48, 23, 4),
(49, 23, 5),
(50, 23, 8),
(51, 24, 1),
(52, 25, 2),
(53, 25, 6),
(54, 25, 8),
(55, 26, 1),
(56, 26, 8),
(57, 27, 4),
(58, 27, 6),
(59, 28, 5),
(60, 28, 9),
(61, 29, 5),
(62, 30, 4),
(63, 30, 7),
(64, 30, 9),
(65, 31, 5),
(66, 31, 7),
(67, 31, 10),
(68, 32, 6),
(69, 32, 7),
(70, 32, 10),
(71, 33, 7),
(72, 34, 4),
(73, 34, 8),
(74, 35, 1),
(75, 35, 2),
(76, 35, 6),
(77, 36, 9),
(78, 36, 10),
(79, 37, 5),
(80, 37, 6),
(81, 37, 9),
(82, 38, 5),
(83, 38, 9),
(84, 39, 1),
(85, 40, 2),
(86, 41, 2),
(87, 42, 5),
(88, 42, 8),
(89, 43, 1),
(90, 43, 5),
(91, 44, 4),
(92, 44, 10),
(93, 45, 7),
(94, 45, 9),
(95, 46, 3),
(96, 46, 7),
(97, 47, 3),
(98, 47, 7),
(99, 48, 1),
(100, 48, 6),
(101, 48, 9),
(102, 49, 1),
(103, 49, 7),
(104, 50, 4),
(105, 50, 5),
(106, 51, 5),
(107, 52, 3),
(108, 52, 9),
(109, 53, 4),
(110, 54, 4),
(111, 54, 5),
(112, 55, 1),
(113, 55, 6),
(114, 55, 8),
(115, 56, 8),
(116, 57, 3),
(117, 57, 10),
(118, 58, 2),
(119, 58, 3),
(120, 58, 6),
(121, 59, 1),
(122, 59, 3),
(123, 60, 5),
(124, 61, 5),
(125, 61, 8),
(126, 62, 4),
(127, 62, 8),
(128, 63, 7),
(129, 63, 10),
(130, 64, 3),
(131, 64, 7),
(132, 65, 4),
(133, 65, 8),
(134, 66, 10),
(135, 67, 1),
(136, 67, 4),
(137, 67, 7),
(138, 68, 10),
(139, 69, 1),
(140, 69, 5),
(141, 70, 1),
(142, 71, 1),
(143, 72, 6),
(144, 73, 2),
(145, 73, 3),
(146, 73, 6),
(147, 74, 6),
(148, 74, 7),
(149, 75, 4),
(150, 76, 4),
(151, 77, 3),
(152, 78, 1),
(153, 78, 4),
(154, 79, 1),
(155, 79, 6),
(156, 79, 9),
(157, 80, 9),
(158, 81, 4),
(159, 82, 5),
(160, 82, 10),
(161, 83, 6),
(162, 84, 8),
(163, 84, 10),
(164, 85, 10),
(165, 86, 5),
(166, 87, 5),
(167, 87, 8),
(168, 87, 10),
(169, 88, 2),
(170, 88, 6),
(171, 88, 9),
(172, 89, 7),
(173, 89, 8),
(174, 90, 4),
(175, 90, 10),
(176, 91, 1),
(177, 91, 5),
(178, 92, 1),
(179, 92, 5),
(180, 92, 8),
(181, 93, 1),
(182, 94, 8),
(183, 95, 2),
(184, 95, 7),
(185, 95, 10),
(186, 96, 3),
(187, 97, 1),
(188, 97, 2),
(189, 98, 2),
(190, 98, 9),
(191, 99, 3),
(192, 99, 6),
(193, 100, 1),
(194, 100, 4),
(195, 100, 6);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `code`, `created_at`, `updated_at`) VALUES
(1, 'ig', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(2, 'mt', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(3, 'ga', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(4, 'nb', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(5, 'as', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(6, 'pi', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(7, 'ka', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(8, 'br', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(9, 'th', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(10, 'kg', '2018-09-28 15:19:24', '2018-09-28 15:19:24');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(15, '2014_10_12_000000_create_users_table', 1),
(16, '2014_10_12_100000_create_password_resets_table', 1),
(17, '2018_09_28_061400_create_developers_table', 1),
(18, '2018_09_28_061434_create_programming_languages_table', 1),
(19, '2018_09_28_061448_create_languages_table', 1),
(20, '2018_09_28_184935_create_language_developer_table', 1),
(21, '2018_09_28_185008_create_programming_language_developer_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `programming_languages`
--

CREATE TABLE `programming_languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `programming_languages`
--

INSERT INTO `programming_languages` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'c', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(2, 'javascript', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(3, 'php', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(4, 'kotlin', '2018-09-28 15:19:24', '2018-09-28 15:19:24'),
(5, 'jave', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(6, 'python', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(7, 'r', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(8, 'ruby', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(9, 'c++', '2018-09-28 15:19:25', '2018-09-28 15:19:25'),
(10, 'cobol', '2018-09-28 15:19:25', '2018-09-28 15:19:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `developers`
--
ALTER TABLE `developers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `developers_email_unique` (`email`);

--
-- Indexes for table `developer_language`
--
ALTER TABLE `developer_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `developer_programming_language`
--
ALTER TABLE `developer_programming_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `languages_code_unique` (`code`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `programming_languages`
--
ALTER TABLE `programming_languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `programming_languages_name_unique` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `developers`
--
ALTER TABLE `developers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `developer_language`
--
ALTER TABLE `developer_language`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT for table `developer_programming_language`
--
ALTER TABLE `developer_programming_language`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `programming_languages`
--
ALTER TABLE `programming_languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
