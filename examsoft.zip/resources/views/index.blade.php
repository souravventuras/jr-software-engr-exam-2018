<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body {
            padding-top: 60px;
        }

        @media (max-width: 980px) {
            body {
                padding-top: 0;
            }
        }

    </style>
</head>
<body>
<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <form action="{{url('/')}}">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search" name="search">
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </form>
            <br>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Email</th>
                    <th>Programming Language</th>
                    <th>Language</th>
                </tr>
                </thead>
                <tbody>

                @foreach($developers as $developer)
                    <tr>
                        <td>{{ $developer->email }}</td>
                        <td>
                            @foreach($developer->programmingLanguage as $eachProgrammingLanguage)
                                {{ $eachProgrammingLanguage->name }}@if (!$loop->last),@endif
                            @endforeach
                        </td>
                        <td>
                            @foreach($developer->language as $eachLanguage)
                                {{ $eachLanguage->code }}@if (!$loop->last),@endif
                            @endforeach
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {!! $developers->appends(Request::except('page'))->render() !!}
        </div>
    </div>
</div>
</body>
</html>
