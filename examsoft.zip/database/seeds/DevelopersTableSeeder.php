<?php

use Illuminate\Database\Seeder;

class DevelopersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();

        for ($i = 0; $i < 100; $i++) {
            $email[] = ['email' => $faker->unique()->safeEmail];
        }



        foreach ($email as $eachEmail) {
            \App\Developer::create($eachEmail);
        }

        /**
         * Populate the pivot table to assign Language to Developer
         */
        $languages = \App\Language::all();
        App\Developer::all()->each(function ($developer) use ($languages) {
            $developer->language()->attach(
                $languages->random(rand(1, 3))->pluck('id')->toArray()
            );
        });


        /**
         * Populate the pivot table to assign ProgrammingLanguage to Developer
         */
        $programmingLanguages = App\ProgrammingLanguage::all();
        App\Developer::all()->each(function ($developer) use ($programmingLanguages) {
            $developer->programmingLanguage()->attach(
                $programmingLanguages->random(rand(1, 3))->pluck('id')->toArray()
            );
        });
        /*App\Developer::All()->each(function ($developer) use ($programmingLanguages) {
            $developer->programmingLanguage()->saveMany($programmingLanguages);
        });*/
    }
}
