<?php

use Illuminate\Database\Seeder;

class LanguagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker\Factory::create();
        $faker->addProvider(new Faker\Provider\Miscellaneous($faker));

        for ($i = 0; $i < 10; $i++) {
            $languages[] = ['code' => $faker->unique()->languageCode];
        }

        foreach ($languages as $language) {
            \App\Language::create($language);
        }
    }
}
