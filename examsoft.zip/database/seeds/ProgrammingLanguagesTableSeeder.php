<?php

use Illuminate\Database\Seeder;

class ProgrammingLanguagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $programmingLanguages = [
            ['name' => 'c'],
            ['name' => 'javascript'],
            ['name' => 'php'],
            ['name' => 'kotlin'],
            ['name' => 'jave'],
            ['name' => 'python'],
            ['name' => 'r'],
            ['name' => 'ruby'],
            ['name' => 'c++'],
            ['name' => 'cobol']
        ];

        foreach ($programmingLanguages as $programmingLanguage) {
            \App\ProgrammingLanguage::create($programmingLanguage);
        }

    }
}
