<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function (\Illuminate\Http\Request $request) {

    $builder = \App\Developer::query();

    if ($request->has('search')) {
        $queryString = $request->search;
        $builder->where('email', 'LIKE', "%$queryString%");

        $builder->orWhereHas('language', function($query) use ($queryString)
        {
            $query->where('code', 'LIKE', "%$queryString%");
        });

        $builder->orWhereHas('programmingLanguage', function($query) use ($queryString)
        {
            $query->where('name', 'LIKE', "%$queryString%");
        });
    }

    $builder->with('language', 'programmingLanguage');
    $developers = $builder->orderBy('email', 'ASC')
        ->paginate(10);

    return view('index', compact('developers'));
});
