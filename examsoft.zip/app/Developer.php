<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Developer extends Model
{
    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function language()
    {
        return $this->belongsToMany('App\Language');
    }


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function programmingLanguage()
    {
        return $this->belongsToMany('App\ProgrammingLanguage');
    }
}
